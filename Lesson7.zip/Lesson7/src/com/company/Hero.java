package com.company;

public abstract class Hero implements HavingSuperAbility {
    private int health;
    private int damage;
    private String superAbility;




}
