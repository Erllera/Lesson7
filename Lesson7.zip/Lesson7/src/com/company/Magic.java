package com.company;

public class Magic extends Hero{
    @Override
    public String applySuperAbility(String SuperAbilityType) {
        return "Маг использовал суперспособность "+ SuperAbilityType;
    }
}
