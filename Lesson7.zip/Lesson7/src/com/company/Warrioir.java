package com.company;

public class Warrioir extends Hero{
    @Override
    public String applySuperAbility(String SuperAbilityType) {
        return "Воин использовал суперспособность "+ SuperAbilityType;
    }
}
