package com.company;

public interface HavingSuperAbility {

    String applySuperAbility(String SuperAbilityType);
}
